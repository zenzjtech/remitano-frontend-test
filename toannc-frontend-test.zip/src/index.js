import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(
  // TODO v5: remove once migration to emotion is completed
  <App />,
  document.querySelector('#root'),
);
